const express = require('express');
const cors = require('cors');
const app = express();
const port = 5000;

app.use(cors());
app.use(express.json());

// Simple RSA encrypt/decrypt functions for demo (replace with your logic)
function modExp(base, exp, mod) {
  let result = 1n;
  let b = BigInt(base);
  let e = BigInt(exp);
  let m = BigInt(mod);

  while (e > 0) {
    if (e % 2n === 1n) result = (result * b) % m;
    b = (b * b) % m;
    e = e / 2n;
  }
  return result;
}

const RSA = {
  p: 61n,
  q: 53n,
  n: 61n * 53n,
  e: 17n,
  d: 2753n,
};

app.post('/encrypt', (req, res) => {
  const { plaintext } = req.body;
  if (plaintext === undefined) {
    return res.status(400).json({ error: 'Plaintext required' });
  }
  const pt = BigInt(plaintext);
  if (pt >= RSA.n) {
    return res.status(400).json({ error: 'Plaintext must be less than n' });
  }
  const encrypted = modExp(pt, RSA.e, RSA.n);
  res.json({ ciphertext: encrypted.toString() });
});

app.post('/decrypt', (req, res) => {
  const { ciphertext } = req.body;
  if (ciphertext === undefined) {
    return res.status(400).json({ error: 'Ciphertext required' });
  }
  const ct = BigInt(ciphertext);
  const decrypted = modExp(ct, RSA.d, RSA.n);
  res.json({ plaintext: decrypted.toString() });
});

app.listen(port, () => {
  console.log(`Backend running at http://localhost:${port}`);
});
