#include <iostream>
#include "BigInt.h"
#include "RSA.h"

int main() {
    // Fixed primes and keys for RSA
    const unsigned long long p = 61;
    const unsigned long long q = 53;
    const unsigned long long e = 17;
    const unsigned long long d = 2753;

    RSA rsa(p, q, e, d);

    std::cout << "RSA Simplified Demo\n";
    std::cout << "Public key (e, n): (" << e << ", " << rsa.getN() << ")\n";
    std::cout << "Private key (d, n): (" << d << ", " << rsa.getN() << ")\n";

    while (true) {
        std::cout << "Enter a number less than " << rsa.getN() << " to encrypt (or 0 to exit): ";
        std::string inputStr;
        std::cin >> inputStr;

        if (inputStr == "0") break;

        try {
            BigInt plaintext(inputStr);

            // Check if input < n
            if (plaintext.mod(rsa.getN()) >= rsa.getN()) {
                std::cerr << "Error: Number too large. Try again.\n";
                continue;
            }

            unsigned long long ciphertext = rsa.encrypt(plaintext);
            unsigned long long decrypted = rsa.decrypt(ciphertext);

            std::cout << "Encrypted ciphertext: " << ciphertext << "\n";
            std::cout << "Decrypted plaintext: " << decrypted << "\n\n";

        } catch (const std::exception& ex) {
            std::cerr << "Invalid input: " << ex.what() << "\n";
        }
    }

    std::cout << "Exiting RSA demo.\n";
    return 0;
}
