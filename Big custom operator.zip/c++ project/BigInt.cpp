#include "BigInt.h"
#include <stdexcept>
#include <algorithm>

BigInt::BigInt() {
    digits.push_back(0);
}

BigInt::BigInt(unsigned long long num) {
    if (num == 0) digits.push_back(0);
    while (num > 0) {
        digits.push_back(num % 10);
        num /= 10;
    }
}

BigInt::BigInt(const std::string &numStr) {
    for (int i = (int)numStr.size() - 1; i >= 0; --i) {
        if (numStr[i] < '0' || numStr[i] > '9')
            throw std::invalid_argument("Invalid digit in string");
        digits.push_back(numStr[i] - '0');
    }
}

bool BigInt::operator==(const BigInt& other) const {
    return digits == other.digits;
}

bool BigInt::operator!=(const BigInt& other) const {
    return !(*this == other);
}

bool BigInt::operator<(const BigInt& other) const {
    if (digits.size() != other.digits.size())
        return digits.size() < other.digits.size();
    for (int i = (int)digits.size() - 1; i >= 0; --i) {
        if (digits[i] != other.digits[i])
            return digits[i] < other.digits[i];
    }
    return false;
}

bool BigInt::operator>(const BigInt& other) const {
    return other < *this;
}

bool BigInt::operator<=(const BigInt& other) const {
    return !(other < *this);
}

bool BigInt::operator>=(const BigInt& other) const {
    return !(*this < other);
}

BigInt BigInt::operator+(const BigInt& other) const {
    BigInt result;
    result.digits.clear();

    int carry = 0;
    size_t n = std::max(digits.size(), other.digits.size());
    for (size_t i = 0; i < n || carry; ++i) {
        int digitSum = carry;
        if (i < digits.size()) digitSum += digits[i];
        if (i < other.digits.size()) digitSum += other.digits[i];
        result.digits.push_back(digitSum % 10);
        carry = digitSum / 10;
    }
    return result;
}

BigInt BigInt::operator*(int num) const {
    BigInt result;
    result.digits.clear();

    int carry = 0;
    for (int d : digits) {
        int prod = d * num + carry;
        result.digits.push_back(prod % 10);
        carry = prod / 10;
    }
    while (carry) {
        result.digits.push_back(carry % 10);
        carry /= 10;
    }
    return result;
}

BigInt BigInt::operator*(const BigInt& other) const {
    BigInt result;
    result.digits.assign(digits.size() + other.digits.size(), 0);

    for (size_t i = 0; i < digits.size(); ++i) {
        int carry = 0;
        for (size_t j = 0; j < other.digits.size() || carry; ++j) {
            long long cur = result.digits[i + j] + (long long)digits[i] * (j < other.digits.size() ? other.digits[j] : 0) + carry;
            result.digits[i + j] = (int)(cur % 10);
            carry = (int)(cur / 10);
        }
    }

    while (result.digits.size() > 1 && result.digits.back() == 0)
        result.digits.pop_back();

    return result;
}

unsigned long long BigInt::mod(unsigned long long m) const {
    unsigned long long result = 0;
    for (int i = (int)digits.size() - 1; i >= 0; --i) {
        result = (result * 10 + digits[i]) % m;
    }
    return result;
}

unsigned long long BigInt::modExp(unsigned long long base, unsigned long long exp, unsigned long long mod) {
    unsigned long long result = 1;
    base %= mod;
    while (exp > 0) {
        if (exp & 1) result = (result * base) % mod;
        base = (base * base) % mod;
        exp >>= 1;
    }
    return result;
}

std::string BigInt::toString() const {
    std::string s;
    for (auto it = digits.rbegin(); it != digits.rend(); ++it)
        s.push_back(*it + '0');
    return s;
}
