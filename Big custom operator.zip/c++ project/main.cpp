#include <iostream>
#include "BigInt.h"

int main() {
    std::string num1, num2;
    int choice;

    std::cout << "Enter first big integer: ";
    std::cin >> num1;
    std::cout << "Enter second big integer: ";
    std::cin >> num2;

    BigInt a(num1);
    BigInt b(num2);

    std::cout << "\nSelect operation to perform:\n";
    std::cout << "1. Add\n2. Subtract\n3. Multiply\n4. Divide\n5. Modulus\n6. Exponentiation (a^b mod m)\n";
    std::cout << "Enter choice (1-6): ";
    std::cin >> choice;

    BigInt result;

    switch (choice) {
        case 1: result = a.add(b); std::cout << "Sum: "; break;
        case 2: result = a.subtract(b); std::cout << "Difference: "; break;
        case 3: result = a.multiply(b); std::cout << "Product: "; break;
        case 4:
            if (b == BigInt("0")) {
                std::cout << "Division by zero error!\n"; return 1;
            }
            result = a.divide(b); std::cout << "Quotient: "; break;
        case 5:
            if (b == BigInt("0")) {
                std::cout << "Modulus by zero error!\n"; return 1;
            }
            result = a.modulus(b); std::cout << "Remainder: "; break;
        case 6: {
            std::string modStr;
            std::cout << "Enter modulus: ";
            std::cin >> modStr;
            BigInt mod(modStr);
            result = a.modExp(b, mod);
            std::cout << "Result (a^b mod m): ";
            break;
        }
        default: std::cout << "Invalid choice.\n"; return 1;
    }

    result.print();
    std::cout << std::endl;
    return 0;
}
