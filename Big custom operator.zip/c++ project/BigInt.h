#ifndef BIGINT_H
#define BIGINT_H

#include <string>
#include <vector>

class BigInt {
    std::vector<int> digits; // Least significant digit first

public:
    BigInt();                       // default 0
    BigInt(unsigned long long num); 
    BigInt(const std::string &numStr);

    // Comparison
    bool operator==(const BigInt& other) const;
    bool operator!=(const BigInt& other) const;
    bool operator<(const BigInt& other) const;
    bool operator>(const BigInt& other) const;
    bool operator<=(const BigInt& other) const;
    bool operator>=(const BigInt& other) const;

    // Arithmetic
    BigInt operator+(const BigInt& other) const;
    BigInt operator*(int num) const;
    BigInt operator*(const BigInt& other) const;

    // Modular operations
    unsigned long long mod(unsigned long long m) const;

    // Modular exponentiation for unsigned long long base and exponent
    static unsigned long long modExp(unsigned long long base, unsigned long long exp, unsigned long long mod);

    std::string toString() const;
};

#endif

