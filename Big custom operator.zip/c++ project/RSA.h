#ifndef RSA_H
#define RSA_H

#include "BigInt.h"

class RSA {
    unsigned long long p, q;
    unsigned long long n;
    unsigned long long phi;
    unsigned long long e;
    unsigned long long d;

public:
    RSA(unsigned long long p_, unsigned long long q_, unsigned long long e_, unsigned long long d_);

    unsigned long long encrypt(const BigInt& plaintext) const;
    unsigned long long decrypt(unsigned long long ciphertext) const;

    unsigned long long getN() const;
};

#endif
