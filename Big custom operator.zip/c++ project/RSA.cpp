#include "RSA.h"

RSA::RSA(unsigned long long p_, unsigned long long q_, unsigned long long e_, unsigned long long d_)
    : p(p_), q(q_), e(e_), d(d_)
{
    n = p * q;
    phi = (p - 1) * (q - 1);
}

unsigned long long RSA::encrypt(const BigInt& plaintext) const {
    unsigned long long pt_mod = plaintext.mod(n);
    return BigInt::modExp(pt_mod, e, n);
}

unsigned long long RSA::decrypt(unsigned long long ciphertext) const {
    return BigInt::modExp(ciphertext, d, n);
}

unsigned long long RSA::getN() const {
    return n;
}
